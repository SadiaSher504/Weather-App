import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const WeatherApp(),
    );
  }
}

class WeatherApp extends StatefulWidget {
  const WeatherApp({super.key});

  @override
  State<WeatherApp> createState() => _WeatherAppState();
}

class _WeatherAppState extends State<WeatherApp> {
  WeatherData? weatherData;
  String errorMessage = '';
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchWeather();
  }

  //function to fetch weather data
  Future<void> fetchWeather() async {
    final response = await http.get(Uri.parse(
        'https://api.openweathermap.org/data/2.5/weather?q=lahore&appid=35d66d8e9e1d71ae762485cf404fe2bb&units=metric'));
    if (response.statusCode == 200) {
      setState(()
      {
        weatherData = WeatherData.fromJSON(json.decode(response.body));
        errorMessage = '';
        isLoading = false;
      });
    }
    else
    {
      setState(() {
        errorMessage = 'Failed to load weather';
        isLoading = false;
      });
    }
  }

  //function to set image according to weather condition
  Widget getWeatherImage() {
    String weatherMain = weatherData?.weather.toLowerCase() ?? '';
    if (weatherMain.contains('cloud')) {
    return Image.asset(isDayTime() ? 'images/dayfewclouds.png' : 'images/nightfewclouds.png',);
    }
    else if (weatherMain.contains('clear'))
    {
      return Image.asset(isDayTime() ? 'images/dayclearsky.png' : 'images/nightclearsky.png',);
    }
    else if (weatherMain.contains('scattered')) {
      return Image.asset(isDayTime() ? 'images/dayscatteredcloud.png' : 'images/nightscatteredcloud.png',);
    }
    else if (weatherMain.contains('broken')) {
      return Image.asset(isDayTime() ? 'images/brokenclouds.png' : 'images/brokenclouds.png',);
    }
    else if (weatherMain.contains('shower')) {
      return Image.asset(isDayTime() ? 'images/showerrain.png' : 'images/showerrain.png',);
    }
    else if (weatherMain.contains('rain')) {
      return Image.asset(isDayTime() ? 'images/dayrain.png' : 'images/nightrain.png', );
    }
    else if (weatherMain.contains('thunderstorm')) {
      return Image.asset('images/dthunderstorm.png',);
    }
    else if (weatherMain.contains('snow')) {
      return Image.asset(isDayTime() ? 'images/snow.png' : 'images/snow.jpg',);
    }
    return Image.asset('images/mist.png',color: Colors.white,);
  }
//Function to get background color/image according to day and night
  BoxDecoration getBackgroundImage() {
    return BoxDecoration(
      image: DecorationImage(
        image: AssetImage(isDayTime() ? 'images/day.jpg' : 'images/calm-night.jpg'),
        fit: BoxFit.cover,
      ),
    );
  }

  // function to check wheather it is day or night
  bool isDayTime() {
    final time = DateTime.now();
    return time.hour >= 6 && time.hour < 18;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: getBackgroundImage(),
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: isLoading
              ? const Center(child: CircularProgressIndicator())
              : errorMessage.isNotEmpty
              ? Center(child: Text(errorMessage))
              : weatherData == null
              ? const Center(child: Text('No weather data available'))
              : buildWeatherInfo(),
        ),
      ),
    );
  }

  Widget buildWeatherInfo() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            '${weatherData!.name}, ${weatherData!.country}',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Colors.white),
          ),
          Text(
            '${weatherData!.temperature} °C',
            style: TextStyle(fontSize: 25, color: Colors.white),
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Text(
              '${weatherData!.weather}',
              style: TextStyle(fontSize: 22, color: Colors.white),
            ),
          ),
          getWeatherImage(),

          Row(

            mainAxisAlignment: MainAxisAlignment.center,
           children: [
             Icon(Icons.wind_power_outlined,color: Colors.white,),
             Container(
               child: Text('  ${weatherData!.windspeed}  km/h ',style: TextStyle(fontSize: 25, color: Colors.white),
               ),
             ),

           ],
          ),

          Padding(
            padding: const EdgeInsets.all(40.0),
            child: Container(
              height: 200,
              width: 450,
              color: Colors.black54,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Text(
                          'Min Temp: ${weatherData!.mintemperature} °C',
                          style: TextStyle(fontSize: 18, color: Colors.white),
                        ),
                        Text(
                          'Humidity: ${weatherData!.humidity}%',
                          style: TextStyle(fontSize: 18, color: Colors.white),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Text(
                          'Feels like: ${weatherData!.feels_like} °C',
                          style: TextStyle(fontSize: 18, color: Colors.white),
                        ),
                        Text(
                          'Max Temp: ${weatherData!.maxtemperature} °C',
                          style: TextStyle(fontSize: 18, color: Colors.white),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class WeatherData {
  final String name;
  final String country;
  final double temperature;
  final int humidity;
  final double maxtemperature;
  final double mintemperature;
  final double feels_like;
  final String weather;
  final double windspeed;

  WeatherData({
    required this.name,
    required this.country,
    required this.temperature,
    required this.humidity,
    required this.feels_like,
    required this.mintemperature,
    required this.maxtemperature,
    required this.weather,
    required this.windspeed
  });

  factory WeatherData.fromJSON(Map<String, dynamic> json) {
    return WeatherData(
      name: json['name'],
      country: json['sys']['country'],
      temperature: json['main']['temp'].toDouble(),
      humidity: json['main']['humidity'].toInt(),
      feels_like: json['main']['feels_like'].toDouble(),
      mintemperature: json['main']['temp_min'].toDouble(),
      maxtemperature: json['main']['temp_max'].toDouble(),
      weather: json['weather'][0]['main'],
      windspeed: json['wind']['speed'].toDouble(),
    );
  }
}
